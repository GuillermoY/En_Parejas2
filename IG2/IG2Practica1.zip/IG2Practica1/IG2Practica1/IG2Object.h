#pragma once

#include <OgreSceneManager.h>
#include <OgreSceneNode.h>
#include <OgreEntity.h>
#include <OgreInput.h>
#include <OgreMath.h>
#include <OgreFrameListener.h>
#include <OgreMeshManager.h>
#include <SDL_keycode.h>
#include <iostream>


using namespace Ogre;
using namespace std;

class IG2Object : public OgreBites::InputListener {

public:

    /**
     * Constructor without parameters.
     */
    IG2Object();

    /**
     * Constructor.
     * @param initPos Initial position for this element.
     * @param node Scene node for this element.
     * @param sceneMng Scene manager.
     */
    IG2Object(Vector3 initPos, SceneNode* node, SceneManager* sceneMng);

    /**
     * Constructor.
     * @param initPos Initial position for this element.
     * @param node Scene node for this element.
     * @param sceneMng Scene manager.
     * @param mesh Mesh that is applied to this element.
     */
    IG2Object(Vector3 initPos, SceneNode* node, SceneManager* sceneMng, String mesh);

    /**
     * Destructor
     */
    ~IG2Object();

    /**
     * Creates a child scene node.
     * @return Creates a new SceneNode as a child of this object.
     */
    SceneNode* createChildSceneNode();

    /**
     * Sets an initial position for this element
     * @param v Vector representing the position of this element.
     */
    void setInitialPosition(Vector3 v);

    /**
     * Moves this element.
     * @param v Vector representing the traslation for this element.
     */
    void move(Vector3 v);

    /**
     * Rotates the node around the Y-axis.
     * @param angle Angle.
     */
    void yaw(const Radian& angle);

    /**
     * Rotates the node around the Z-axis.
     * @param angle Angle.
     */
    void roll(const Radian& angle);

    /**
     * Rotates the node around the X-axis.
     * @param angle Angle.
     */
    void pitch(const Radian& angle);

    /**
     * Rotates the node given a quaternion q.
     * @param q Quaterion used for the rotation.
     */
    void rotate(const Quaternion& q);

    /**
     * Sets a position for this element
     * @param v Vector representing the position of this element.
     */
    void setPosition(Vector3 v);

    /**
     * Gets the position of this element.
     * @return Position of this element.
     */
    Vector3 getPosition();

    /**
     * Sets the scale for this element.
     * @param vScale Vector representing the scale for this element.
     */
    void setScale(Vector3 vScale);

    /**
     * Sets if the entity of this object is visible or not.
     * @param visible If true, the element is visible. The element is not visible otherwise.
     */
    void setVisible(bool visible);

    /**
     * Gets the AABB for this element.
     * @return AABB of this element.
     */
    const AxisAlignedBox& getAABB();

    /**
     * Gets the orientation for this element.
     * @return Vector representing the orientation for this element.
     */
    Vector3 getOrientation();

    /**
     * Gets the orientation of this element in the grid.
     * @return Vector representing the orientation of this element in the grid.
     * This is the orientation of the element in the grid, which is different from the orientation of the element in the scene. The orientation of the element in the grid is always a multiple of 90 degrees.
     */
    Vector3 getGridOrientation();

    /**
     * Sets the name of the material to be applied to this element.
     * @param materialName Name of the material.
     */
    void setMaterialName(string materialName);

    /**
     * Calculates if this element has an attached entity.
     * @return True if this element has an attached entity, or false in another case.
     */
    bool hasEntity();

    /**
     * Removes the entity attached to this element.
     */
    void removeEntity();

    /**
     * Calculates the bounding-box size of the entity
     * @return Vector representing the size of the AABB
     */
    Vector3 calculateBoxSize();


protected:

    // Scene node representing this element in the scene
    SceneNode* mNode = nullptr;

    // Scene manager
    SceneManager* mSM = nullptr;

    // Entity for this element
    Ogre::Entity* entity = nullptr;

    // Initial position of this element
    Vector3 initialPosition;
};
