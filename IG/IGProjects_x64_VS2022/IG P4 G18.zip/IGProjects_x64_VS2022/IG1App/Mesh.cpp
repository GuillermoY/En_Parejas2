#include "Mesh.h"

using namespace std;
using namespace glm;

// Placeholder for the pending index of a GPU object
constexpr GLuint NONE = numeric_limits<GLuint>::max();

Mesh::Mesh()
	: mVAO(NONE)
	, mVBO(NONE)
	, mCBO(NONE)
	, mTCO(NONE)
	, mNBO(NONE)
{
}

Mesh::~Mesh()
{
	unload();
}

void
Mesh::draw() const
{
	glDrawArrays(
		mPrimitive,
		0,
		size()); // primitive graphic, first index and number of elements to be rendered
}

void
Mesh::load()
{
	assert(mVBO == NONE); // not already loaded

	if (vVertices.size() > 0) { // transfer data
		glGenBuffers(1, &mVBO);
		glGenVertexArrays(1, &mVAO);

		glBindVertexArray(mVAO);
		glBindBuffer(GL_ARRAY_BUFFER, mVBO);
		glBufferData(GL_ARRAY_BUFFER, vVertices.size() * sizeof(vec3), vVertices.data(), GL_STATIC_DRAW);
		glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(vec3), nullptr);
		glEnableVertexAttribArray(0);

		if (vColors.size() > 0) {             // upload colors
			glGenBuffers(1, &mCBO);

			glBindBuffer(GL_ARRAY_BUFFER, mCBO);
			glBufferData(GL_ARRAY_BUFFER, vColors.size() * sizeof(vec4), vColors.data(), GL_STATIC_DRAW);
			glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, sizeof(vec4), nullptr);
			glEnableVertexAttribArray(1);
		}


		if (vTexCoords.size() > 0) {             // upload texture
			glGenBuffers(1, &mTCO);
			glBindBuffer(GL_ARRAY_BUFFER, mTCO);
			glBufferData(GL_ARRAY_BUFFER, vTexCoords.size() * sizeof(vec2), vTexCoords.data(), GL_STATIC_DRAW);
			glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, sizeof(vec2), nullptr); // 0 v�rtices, 1 es el color, 2 textura				 (x,y)
			glEnableVertexAttribArray(2); // 0 v�rtices, 1 es el color, 2 textura
		}

		//AP 57
		if (vNormals.size() > 0) {             // upload normals
			glGenBuffers(1, &mNBO);
			glBindBuffer(GL_ARRAY_BUFFER, mNBO);
			glBufferData(GL_ARRAY_BUFFER, vNormals.size() * sizeof(vec3), vNormals.data(), GL_STATIC_DRAW);
			glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, sizeof(vec3), nullptr); // 0 v�rtices, 1 es el color, 2 textura, 3 normales	 (x,y)
			glEnableVertexAttribArray(3); // 0 v�rtices, 1 es el color, 2 textura, 3 normales
		}
	}
}

void
Mesh::unload()
{
	if (mVAO != NONE) {
		glDeleteVertexArrays(1, &mVAO);
		glDeleteBuffers(1, &mVBO);
		mVAO = NONE;
		mVBO = NONE;

		if (mCBO != NONE) {
			glDeleteBuffers(1, &mCBO);
			mCBO = NONE;
		}
		if (mTCO != NONE) {
			glDeleteBuffers(1, &mTCO);
			mTCO = NONE;
		}
		if (mNBO != NONE) {
			glDeleteBuffers(1, &mNBO);
			mNBO = NONE;
		}
	}
}

void
Mesh::render() const
{
	assert(mVAO != NONE);

	glBindVertexArray(mVAO);
	draw();
}

Mesh*
Mesh::createRGBAxes(GLdouble l)
{
	Mesh* mesh = new Mesh();

	mesh->mPrimitive = GL_LINES;

	mesh->mNumVertices = 6;
	mesh->vVertices.reserve(mesh->mNumVertices);

	// X axis vertices
	mesh->vVertices.emplace_back(0.0, 0.0, 0.0);
	mesh->vVertices.emplace_back(l, 0.0, 0.0);
	// Y axis vertices
	mesh->vVertices.emplace_back(0, 0.0, 0.0);
	mesh->vVertices.emplace_back(0.0, l, 0.0);
	// Z axis vertices
	mesh->vVertices.emplace_back(0.0, 0.0, 0.0);
	mesh->vVertices.emplace_back(0.0, 0.0, l);

	mesh->vColors.reserve(mesh->mNumVertices);
	// X axis color: red  (Alpha = 1 : fully opaque)
	mesh->vColors.emplace_back(1.0, 0.0, 0.0, 1.0);
	mesh->vColors.emplace_back(1.0, 0.0, 0.0, 1.0);
	// Y axis color: green
	mesh->vColors.emplace_back(0.0, 1.0, 0.0, 1.0);
	mesh->vColors.emplace_back(0.0, 1.0, 0.0, 1.0);
	// Z axis color: blue
	mesh->vColors.emplace_back(0.0, 0.0, 1.0, 1.0);
	mesh->vColors.emplace_back(0.0, 0.0, 1.0, 1.0);

	return mesh;
}

Mesh*
Mesh::generateRegularPolygon(GLuint num, GLdouble r)
{
	Mesh* mesh = new Mesh();

	mesh->mPrimitive = GL_LINE_LOOP; // Une el �ltimo v�rtice con el primero

	mesh->mNumVertices = num;
	double angle = 90.0;
	// Dividimos un c�rculo como un pastel y ponemos v�rtices en cada intersecci�n
	// entre la l�nea y la circunferencia.
	for (GLuint i = 0; i < num; ++i)
	{
		// Las funciones trigonom�tricas tienen que estar en radianes para su aplicaci�n
		double x = 0 + r * cos(glm::radians(angle));
		double y = 0 + r * sin(glm::radians(angle));
		mesh->vVertices.emplace_back(x, y, 0.0);
		angle += 360 / num;
	}

	return mesh;
}

/// <summary>
/// Apartado 7: 
/// Generamos un pol�gono regular de 3 lados, cambiando sus v�rtices 1 a 1 para 
/// que contenga RGB
/// </summary>
Mesh*
Mesh::generateRGBTriangle(GLdouble h)
{
	Mesh* mesh = generateRegularPolygon(3, h);
	mesh->mPrimitive = GL_TRIANGLE_STRIP;
	mesh->vColors.emplace_back(1.0, 0.0, 0.0, 1.0);
	mesh->vColors.emplace_back(0.0, 1.0, 0.0, 1.0);
	mesh->vColors.emplace_back(0.0, 0.0, 1.0, 1.0);

	return mesh;
}

/// <summary>
/// Apartado 8:
/// Generamos los cuatro v�rtices del rect�ngulo centrado en el origen, sobre el plano Z = 0,
/// de ancho y alto. Utilizando GL_TRIANGLE_STRIP.
/// </summary>
Mesh*
Mesh::generateRectangle(GLdouble w, GLdouble h)
{
	Mesh* mesh = new Mesh();

	mesh->mPrimitive = GL_TRIANGLE_STRIP;

	mesh->mNumVertices = 4;

	mesh->vVertices.emplace_back(w / 2, h / 2, 0.0);
	mesh->vVertices.emplace_back(-w / 2, h / 2, 0.0);
	mesh->vVertices.emplace_back(w / 2, -h / 2, 0.0);
	mesh->vVertices.emplace_back(-w / 2, -h / 2, 0.0);
	return mesh;
}
/// <summary>
/// Apartado 8.2:
/// 
/// Al igual que el tri�ngulo, a�adimos un color primario a cada v�rtice de un rect�ngulo.
/// </summary>
Mesh*
Mesh::generateRGBRectangle(GLdouble w, GLdouble h)
{
	Mesh* mesh = generateRectangle(w, h);
	mesh->vColors.emplace_back(1.0, 0.0, 0.0, 1.0);
	mesh->vColors.emplace_back(0.0, 1.0, 0.0, 1.0);
	mesh->vColors.emplace_back(0.0, 1.0, 0.0, 1.0);
	mesh->vColors.emplace_back(0.0, 0.0, 1.0, 1.0);

	return mesh;
}


Mesh*
Mesh::generateCube(GLdouble l)
{
	Mesh* mesh = new Mesh();

	mesh->mPrimitive = GL_TRIANGLES;

	mesh->mNumVertices = 36;

	//Cara 1

	mesh->vVertices.emplace_back(l, -l, l);
	mesh->vVertices.emplace_back(l, l, l);
	mesh->vVertices.emplace_back(-l, -l, l);

	mesh->vVertices.emplace_back(l, l, l);
	mesh->vVertices.emplace_back(-l, l, l);
	mesh->vVertices.emplace_back(-l, -l, l);

	//Cara 2

	mesh->vVertices.emplace_back(-l, -l, -l);
	mesh->vVertices.emplace_back(-l, l, -l);
	mesh->vVertices.emplace_back(l, l, -l);

	mesh->vVertices.emplace_back(l, l, -l);
	mesh->vVertices.emplace_back(l, -l, -l);
	mesh->vVertices.emplace_back(-l, -l, -l);

	//Cara 3

	mesh->vVertices.emplace_back(l, -l, -l);
	mesh->vVertices.emplace_back(l, l, -l);
	mesh->vVertices.emplace_back(l, l, l);

	mesh->vVertices.emplace_back(l, -l, -l);
	mesh->vVertices.emplace_back(l, l, l);
	mesh->vVertices.emplace_back(l, -l, l);

	//Cara 4

	mesh->vVertices.emplace_back(-l, -l, l);
	mesh->vVertices.emplace_back(-l, l, l);
	mesh->vVertices.emplace_back(-l, l, -l);

	mesh->vVertices.emplace_back(-l, -l, l);
	mesh->vVertices.emplace_back(-l, l, -l);
	mesh->vVertices.emplace_back(-l, -l, -l);

	//Cara 5

	mesh->vVertices.emplace_back(l, l, l);
	mesh->vVertices.emplace_back(l, l, -l);
	mesh->vVertices.emplace_back(-l, l, -l);

	mesh->vVertices.emplace_back(l, l, l);
	mesh->vVertices.emplace_back(-l, l, -l);
	mesh->vVertices.emplace_back(-l, l, l);

	//Cara 6
	mesh->vVertices.emplace_back(-l, -l, -l);
	mesh->vVertices.emplace_back(l, -l, -l);
	mesh->vVertices.emplace_back(l, -l, l);

	mesh->vVertices.emplace_back(-l, -l, -l);
	mesh->vVertices.emplace_back(l, -l, l);
	mesh->vVertices.emplace_back(-l, -l, l);

	return mesh;
}

Mesh*
Mesh::generateRGBCubeTriangles(GLdouble l)
{
	Mesh* mesh = generateCube(l);
	float aux[3] = { 0 };
	for (int i = 0; i < 3; ++i)
	{
		aux[i] = 1.0;
		for (int j = 0; j < 12; ++j)
		{
			mesh->vColors.emplace_back(aux[0], aux[1], aux[2], 1.0);
		}
		aux[i] = 0.0;
	}

	return mesh;
}

Mesh*
Mesh::generateRectangleTexCor(GLdouble w, GLdouble h, GLuint rw, GLuint rh)
{
	Mesh* mesh = generateRectangle(w, h);
	mesh->vTexCoords.reserve(mesh->mNumVertices);
	mesh->vTexCoords.emplace_back(0, rh);
	mesh->vTexCoords.emplace_back(0, 0);
	mesh->vTexCoords.emplace_back(rw, rh);
	mesh->vTexCoords.emplace_back(rw, 0);
	return mesh;
}

Mesh*
Mesh::generateBoxOutline(GLdouble length)
{
	Mesh* mesh = new Mesh();

	mesh->mPrimitive = GL_TRIANGLE_STRIP;

	mesh->mNumVertices = 10;	
	
	mesh->vVertices.emplace_back(-length, -length, -length);
	mesh->vVertices.emplace_back(-length, length, -length);
	mesh->vVertices.emplace_back(-length, -length, length);
	mesh->vVertices.emplace_back(-length, length, length);


	mesh->vVertices.emplace_back(length, -length, length);
	mesh->vVertices.emplace_back(length, length, length);
	mesh->vVertices.emplace_back(length, -length, -length);
	mesh->vVertices.emplace_back(length, length, -length);

	mesh->vVertices.emplace_back(-length, -length, -length);
	mesh->vVertices.emplace_back(-length, length, -length);
	
	return mesh;
}

Mesh*
Mesh::generateBoxOutlineTexCor(GLdouble length)
{
	Mesh* mesh = generateBoxOutline(length);
	mesh->vTexCoords.reserve(mesh->mNumVertices);

	mesh->vTexCoords.emplace_back(0, 1);
	mesh->vTexCoords.emplace_back(0, 0);
	mesh->vTexCoords.emplace_back(1, 1);
	mesh->vTexCoords.emplace_back(1, 0);

	mesh->vTexCoords.emplace_back(0, 1);
	mesh->vTexCoords.emplace_back(0, 0);
	mesh->vTexCoords.emplace_back(1, 1);
	mesh->vTexCoords.emplace_back(1, 0);

	mesh->vTexCoords.emplace_back(0, 1);
	mesh->vTexCoords.emplace_back(0, 0);

	return mesh;
}

Mesh*
Mesh::generateStar3D(GLdouble re, GLuint np, GLdouble h)
{
	Mesh* mesh = new Mesh();

	mesh->mPrimitive = GL_TRIANGLE_FAN;

	mesh->mNumVertices = np * 2 + 2; // Internos + Externos + El punto 0,0 + Cerrar Estrella

	mesh->vVertices.emplace_back(0, 0, 0);

	GLuint ri = re / 2.0;

	double angle = 90.0;
	double ai = angle + (180/np); // Rotaci�n a�adida
	// Dividimos un c�rculo como un pastel y ponemos v�rtices en cada intersecci�n
	// entre la l�nea y la circunferencia.
	for (GLuint i = 0; i < np; ++i)
	{
		// Las funciones trigonom�tricas tienen que estar en radianes para su aplicaci�n
		double x = 0 + re * cos(glm::radians(angle));
		double y = 0 + re * sin(glm::radians(angle));
		mesh->vVertices.emplace_back(x, y, h); // Z = h

		//Puntos internos
		double x2 = 0 + ri * cos(glm::radians(ai));
		double y2 = 0 + ri * sin(glm::radians(ai));
		mesh->vVertices.emplace_back(x2, y2, h);

		angle += 360 / np;

		ai += 360 / np;
	}
	double x = 0 + re * cos(glm::radians(angle));
	double y = 0 + re * sin(glm::radians(angle));
	mesh->vVertices.emplace_back(x, y, h); // �ltimo v�rtice que cierra la estrella

	return mesh;
}
#include <iostream>
#include <string>
Mesh*
Mesh::generateStar3DTexCor(GLdouble re, GLuint np, GLdouble h) // Ap 29
{
	Mesh* mesh = generateStar3D(re, np, h);
	mesh->vTexCoords.reserve(mesh->mNumVertices);


	double center = 0.5; // el centro de la imagen es 0.5
	double reImg = 0.5;
	double riImg = 0.25;

	mesh->vTexCoords.emplace_back(center, center);

	GLuint ri = re / 2;

	double angle = 90.0;
	double ai = angle + (180 / np); // Rotaci�n a�adida

	// Dividimos un c�rculo como un pastel y ponemos v�rtices en cada intersecci�n
	// entre la l�nea y la circunferencia.
	for (GLuint i = 0; i < np; ++i)
	{
		// Las funciones trigonom�tricas tienen que estar en radianes para su aplicaci�n
		double x = center + reImg * cos(glm::radians(angle));
		double y = center + reImg * sin(glm::radians(angle));
		mesh->vTexCoords.emplace_back(x, y);
		//Puntos internos
		double x2 = center + riImg * cos(glm::radians(ai));
		double y2 = center + riImg * sin(glm::radians(ai));
		mesh->vTexCoords.emplace_back(x2,y2);

		angle += 360 / np;

		ai += 360 / np;
	}
	double x = center + reImg * cos(glm::radians(angle));
	double y = center + reImg * sin(glm::radians(angle));
	mesh->vTexCoords.emplace_back(x, y); // �ltimo v�rtice que cierra la estrella

	return mesh;
}
