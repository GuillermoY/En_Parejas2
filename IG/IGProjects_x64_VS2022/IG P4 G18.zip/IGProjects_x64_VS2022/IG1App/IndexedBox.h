#ifndef INDEXEDBOX_H
#define INDEXEDBOX_H_H
#include <GL/glew.h>
#include <glm/glm.hpp>
#include "IndexMesh.h"
#include "ColorMaterialEntity.h"

/// <summary>
/// AP 62: Cubo indexado que hereda de ColorMaterialEntity para tener iluminaci�n.
/// AP 64: Usa generateIndexedBox (24 v�rtices) en lugar de generateIndexedBox8 (8 v�rtices)
///        para tener normales correctas por cara.
/// </summary>
class IndexedBox : public ColorMaterialEntity
{
public:
    explicit IndexedBox(GLdouble l);
};
#endif