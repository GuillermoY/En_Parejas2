#ifndef _H_Mesh_H_
#define _H_Mesh_H_

#include <GL/glew.h>
#include <glm/glm.hpp>

#include <vector>

class Mesh
{
public:
	static Mesh* createRGBAxes(GLdouble l); // creates a new 3D-RGB axes mesh

	static Mesh* generateRegularPolygon(GLuint num, GLdouble r); // Apartado 2: Crea un pol�gono regular dividiendo una circunferencia de radio r en secciones num
	static Mesh* generateRGBTriangle(GLdouble h); // Crea 
	static Mesh* generateRectangle(GLdouble w, GLdouble h);
	static Mesh* generateRGBRectangle(GLdouble w, GLdouble h);
	static Mesh* generateCube(GLdouble length);
	static Mesh* generateRGBCubeTriangles(GLdouble length);

	static Mesh* generateRectangleTexCor(GLdouble w, GLdouble h, GLuint rw, GLuint rh); // Apartado 20 y 21

	static Mesh* generateBoxOutline(GLdouble length); // Ap 22
	static Mesh* generateBoxOutlineTexCor(GLdouble length); // Ap 23

	static Mesh* generateStar3D(GLdouble re, GLuint np, GLdouble h); // Ap 26

	static Mesh* generateStar3DTexCor(GLdouble re, GLuint np, GLdouble h); // Ap 29

	Mesh();
	virtual ~Mesh();

	Mesh(const Mesh& m) = delete;            // no copy constructor
	Mesh& operator=(const Mesh& m) = delete; // no copy assignment

	virtual void render() const;

	GLuint size() const { return mNumVertices; }; // number of elements
	std::vector<glm::vec2> const& textures() const { return vTexCoords; };
	std::vector<glm::vec3> const& vertices() const { return vVertices; };
	std::vector<glm::vec4> const& colors() const { return vColors; };

	void load();
	void unload();

protected:
	GLuint mPrimitive =
	  GL_TRIANGLES;          // graphic primitive: GL_POINTS, GL_LINES, GL_TRIANGLES, ...
	GLuint mNumVertices = 0; // number of elements ( = vVertices.size())

	std::vector<glm::vec2> vTexCoords; // texture array
	std::vector<glm::vec3> vVertices; // vertex array
	std::vector<glm::vec4> vColors;   // color array
	virtual void draw() const;

	GLuint mVAO;  // vertex array object

private:
	GLuint mVBO;  // vertex buffer object
	GLuint mCBO;  // color buffer object
	GLuint mTCO;  // texture buffer object
};

#endif //_H_Scene_H_
